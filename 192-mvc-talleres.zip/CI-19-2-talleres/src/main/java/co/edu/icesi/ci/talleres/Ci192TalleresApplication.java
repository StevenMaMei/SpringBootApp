package co.edu.icesi.ci.talleres;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import co.edu.icesi.ci.talleres.repositories.ServiciosRepository;

@SpringBootApplication
public class Ci192TalleresApplication {

	@Autowired
	private ServiciosRepository serviciosRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(Ci192TalleresApplication.class, args);
	}

}
