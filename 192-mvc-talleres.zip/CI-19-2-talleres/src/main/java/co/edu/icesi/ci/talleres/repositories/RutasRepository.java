package co.edu.icesi.ci.talleres.repositories;

import org.springframework.data.repository.CrudRepository;
import co.edu.icesi.ci.talleres.model.Tmio1Ruta;

public interface RutasRepository extends CrudRepository<Tmio1Ruta, Integer> {

}
