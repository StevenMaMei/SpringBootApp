package co.edu.icesi.ci.talleres.repositories;

import org.springframework.data.repository.CrudRepository;
import co.edu.icesi.ci.talleres.model.Tmio1Conductore;

public interface ConductoresRepository extends CrudRepository<Tmio1Conductore, String> {

}
